//
//  BluetoothDemoTests.m
//  BluetoothDemoTests
//
//  Created by Mugunth on 14/7/13.
//  Copyright (c) 2013 Steinlogic Consulting and Training Pte Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface BluetoothDemoTests : XCTestCase

@end

@implementation BluetoothDemoTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
