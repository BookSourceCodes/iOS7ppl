//
//  ViewController.h
//  SimpleLayout
//
//  Created by Rob Napier on 8/25/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
