//
//  AppDelegate.m
//  Columns
//
//  Created by Rob Napier on 8/26/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

@synthesize window = _window;

@end
