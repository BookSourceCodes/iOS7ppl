//
//  ViewController.m
//  DuplicateLayout
//
//  Created by Rob Napier on 8/12/13.
//  Copyright (c) 2013 Rob Napier. All rights reserved.
//

#import "ViewController.h"
#import "LayoutView.h"

@interface ViewController () <UITextViewDelegate>
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet LayoutView *layoutView;

@end

@implementation ViewController


@end
