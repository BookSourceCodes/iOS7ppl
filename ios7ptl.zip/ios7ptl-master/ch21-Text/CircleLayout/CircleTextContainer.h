//
// CircleTextContainer
// Based on code from Apple's TextLayoutDemo

#import <Foundation/Foundation.h>

@interface CircleTextContainer : NSTextContainer

@end
