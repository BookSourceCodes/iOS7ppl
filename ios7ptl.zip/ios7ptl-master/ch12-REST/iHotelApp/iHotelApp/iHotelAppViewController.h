//
//  iHotelAppViewController.h
//  iHotelApp
//

#import <UIKit/UIKit.h>
#import "RESTfulEngine.h"

@interface iHotelAppViewController : UIViewController

@end
