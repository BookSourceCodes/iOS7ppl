//
//  iHotelAppMenuViewController.h
//  iHotelApp
//
//  Created by Mugunth on 28/6/12.
//  Copyright (c) 2012 Steinlogic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iHotelAppMenuViewController : UIViewController

@end
