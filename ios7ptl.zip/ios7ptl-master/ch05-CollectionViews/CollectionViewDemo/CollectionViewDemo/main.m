//
//  main.m
//  CollectionViewTest
//
//  Created by Mugunth on 4/9/12.
//  Copyright (c) 2012 Steinlogic Consulting and Training. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MKAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([MKAppDelegate class]));
  }
}
