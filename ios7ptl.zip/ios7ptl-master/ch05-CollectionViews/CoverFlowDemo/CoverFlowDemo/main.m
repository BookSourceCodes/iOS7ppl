//
//  main.m
//  CoverFlowDemo
//
//  Created by Mugunth on 7/12/12.
//  Copyright (c) 2012 Steinlogic Consulting and Training Pte Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SCTAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([SCTAppDelegate class]));
  }
}
