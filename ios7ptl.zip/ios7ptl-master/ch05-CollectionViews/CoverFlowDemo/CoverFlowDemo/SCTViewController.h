//
//  SCTViewController.h
//  CoverFlowDemo
//
//  Created by Mugunth on 7/12/12.
//  Copyright (c) 2012 Steinlogic Consulting and Training Pte Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCTViewController : UIViewController

@end
