//
//  SCTCarouselLayout.h
//  iOS PTL
//
//  Created by Mugunth on 6/12/12.
//  Copyright (c) 2012 Steinlogic Consulting and Training Pte Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MKCoverFlowLayout : UICollectionViewFlowLayout

@end
